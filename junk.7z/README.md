# LMS-for-people-with-ID
 
Running Mongodb docker:
```
docker run --name mongodb -d -p 27017:27017 -v $(pwd)/mongodata:/data/db mongo 
```

Ref: https://www.mongodb.com/compatibility/docker