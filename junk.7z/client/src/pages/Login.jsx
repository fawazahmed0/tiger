import { Dashcard } from "../components/Dashcard";
import "bootstrap-icons/font/bootstrap-icons.css";
import { useEffect, useState, Fragment } from 'react';

export default function Dashboard() {

    useEffect(() => {
        document.title = 'Dashboard';
      });

      const response =  await fetch('http://localhost:1971/api/getdetails', {
        headers:{
            'Content-Type' : 'application/json'
        },
        method: 'POST',
        body: JSON.stringify({ 
            token:localStorage.getItem('token'),
        })
    })

    const data = await response.json()

    const dashcardData = [
       {"title":"Teacher", gradient:"linear-gradient(45deg,#4099ff,#73b4ff)", count:"54+", iconimg:<i className="bi bi-person" />},
       {"title":"Parents", gradient:"linear-gradient(45deg, #2ed8b6, #59e0c5)", count:"54+", iconimg:<i className="bi bi-people-fill" />},
       {"title":"Students", gradient:"linear-gradient(45deg, #FFB64D, #ffcb80)", count:"54+", iconimg:<i className="bi bi-person" />},
       {"title":"Psychiatrists", gradient:"linear-gradient(45deg, #FF5370, #ff869a)", count:"54+", iconimg:<i className="bi bi-person" />},
       {"title":"Medical Officers", gradient:"linear-gradient(45deg, #FFB64D, #ffcb80)", count:"54+", iconimg:<i className="bi bi-person" />},
       {"title":"Clinical Assistants", gradient:"linear-gradient(45deg, #42f5f2, #42c5f5)", count:"54+", iconimg:<i className="bi bi-person" />}
    ]

   const dashCards = dashcardData.map(e=><Dashcard title={e.title} gradient={e.gradient} count={e.count} iconimg={e.iconimg} />)

    return (
    <Fragment>
        {dashCards}
    </Fragment>
    );
  }
