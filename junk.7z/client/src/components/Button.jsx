
export function Button(props) {
    return <button type={props.type || "button"} className={`btn border rounded-pill px-2 ${props.className}`} style={props.style}>{props.text}</button>;
  }