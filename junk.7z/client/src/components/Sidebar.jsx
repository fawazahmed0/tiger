export function Sidebar(props) {

    
    let sideBarArr = []
    let count=0
    for(let [key, value] of Object.entries(props.sidebarobj)){

        let sideBarInnerArr = []
        for(let data of value)
        sideBarInnerArr.push(<li><a href={data.href} className="link-dark rounded">{data.title}</a></li>)
        let id =  `dashboard-collapse${count}`
        let target = `#${id}`
        sideBarArr.push(        
            <li className="mb-1">
            <button className="btn btn-toggle align-items-center rounded collapsed" data-bs-toggle="collapse" data-bs-target={target} aria-expanded="false">
              {key}
            </button>
            <div className="collapse" id={id}>
              <ul className="btn-toggle-nav list-unstyled fw-normal pb-1 small">
                {sideBarInnerArr}
              </ul>
            </div>
          </li>)
          count++;
    }


    return (
        <div className="flex-shrink-0 p-3 bg-white" style={{ width: '280px'}}>
        <a href="/" className="d-flex align-items-center pb-3 mb-3 link-dark text-decoration-none border-bottom">
          <svg className="bi me-2" width="30" height="24"></svg>
          <span className="fs-5 fw-semibold">{props.title}</span>
        </a>
        <ul className="list-unstyled ps-0">
        {sideBarArr}
        </ul>
      </div>
    );
 




}