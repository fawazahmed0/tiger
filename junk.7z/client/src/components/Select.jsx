export function Select(props) {

     
    const optionslist = Object.entries(props.pairs).map(([key,value]) => <option value={key}>{value}</option>);

   return ( <select className="form-select rounded-pill my-2 p-2" aria-label={props.initialvalue}>
    <option selected>{props.initialvalue}</option>
    {optionslist}
    
  </select>
   );
  }