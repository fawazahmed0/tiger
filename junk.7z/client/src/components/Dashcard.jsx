export function Dashcard(props) {



    return ( 
        <div className="card p-4 m-2" style={{ width: '18rem', background: `${props.gradient}` }}>
        <div className="card-body" style={{ color: 'white'}}>
            <p className="text-end fs-3">{props.count}</p>
            {props.iconimg}
            <p className="card-text fs-4">{props.title}</p>
        </div>
        </div>
       );

   }


