export function Input(props) {
   return ( 
    <input {...props} type={props.type} className="form-control rounded-pill my-2 p-2" id={props.id} placeholder={props.placeholder}/>
   );
  }