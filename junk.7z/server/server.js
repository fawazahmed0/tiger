
const express = require('express')
const mongoose = require('mongoose')
const app = express()
const User = require('./models/User')
const port = 1971
var jwt = require('jsonwebtoken');


const cors = require('cors')

const secretKey = 'adfusdfi@SECRETKEY'

async function main(){
  
await mongoose.connect('mongodb://localhost:27017/simpledb');

// use cors middleware to avoid cors issues
app.use(cors())

// parse everything as json for req.body
app.use(express.json())

app.get('/', (req, res) => {
  res.send('Hello World!')
})

app.post('/api/login', async (req, res) => {

  
  const user = await User.findOne({
    mobileNum: req.body.mobileNum,
    password: req.body.password
  })
  if(user){
    const token = jwt.sign({ mobileNum: user.mobileNum }, secretKey);
    res.status(200).json({status:'ok', mobileNum: user.mobileNum , token:token})
  }
  else
    res.status(401).json({status:'error', user: false})
  
})

app.post('/api/getdetails', async (req, res) => {

  var decoded = jwt.verify(req.body.token, secretKey);
  console.log(decoded.mobileNum) // bar
  const user = await User.findOne({
    mobileNum: decoded.mobileNum
  })
  if(user){
    res.status(200).json({status:'ok', user: false, name: user.name})
  }
  else
    res.status(404).json({status:'error', user: false})
})



app.post('/api/register', async (req, res) => {
  try{
    await User.create({
      name: req.body.name,
      mobileNum: req.body.mobileNum,
      password: req.body.password
    })

    res.status(200).json({status:'ok', user:'Generated'})

  }catch(err){
    console.error(err)
    res.status(403).json({status:'error', error:'Duplicate'})
  }
})

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})

}

main()
